package com.sunx.mysprmdbapp1.security;


import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

 
import java.io.IOException;

public class JwtSuccessHandler implements AuthenticationSuccessHandler{
 /*   @Override
    public void onAuthenticationSuccess(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Authentication authentication) throws IOException, ServletException {
        System.out.println("Successfully Authentication");
    } */

	@Override
	public void onAuthenticationSuccess( HttpServletRequest request,
			 HttpServletResponse response, Authentication authentication)
			throws IOException, jakarta.servlet.ServletException {
		// TODO Auto-generated method stub
		System.out.println("Authetification with success!");
	}
}