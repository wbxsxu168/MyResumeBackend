package com.sunx.mysprmdbapp1.controllers;

//  Obsoleted

import com.sunx.mysprmdbapp1.model.JwtUser;
import com.sunx.mysprmdbapp1.security.JwtGenerator;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/login")
public class JwtTokenController {


    private JwtGenerator jwtGenerator;

    public JwtTokenController(JwtGenerator jwtGenerator) {
        this.jwtGenerator = jwtGenerator;
    }

    @PostMapping
    public String generate(@RequestBody final JwtUser jwtUser) {

        return jwtGenerator.generate(jwtUser);

    }
}